#include <list>
#include <vector>
#include <cstring>
#include <pthread.h>
#include <thread>
#include <string>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include <cmath>
#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "Includes/Utils.hpp"
#include "Menu/Menu.hpp"
#include "Menu/Jni.hpp"
#include "Includes/Macros.h"
#include "dobby.h"

// Menü-Einstellungen
bool enableAimbot = false;
bool enableESP = false;
float aimHeight = 1.4f;

struct Vector3 {
float x, y, z;
};

// Deine Dead Trigger Funktionszeiger
Vector3 (*WorldToScreenPoint)(void *camera, Vector3 position);
void *(*Camera_get_main)();
Vector3 (*Transform_get_position)(void *transform);
void (*Transform_LookAt)(void *transform, Vector3 worldPosition);
void *(*Component_get_transform)(void *component);
bool (*Agent_get_IsAlive)(void *agent);
bool (*Agent_get_IsPlayer)(void *agent);

// Speicher für den nächsten Zombie
void *closestEnemy = nullptr;
float closestDistance = 99999.0f;
void *localPlayer = nullptr;

// Menü-Schalter definieren
jobjectArray GetFeatureList(JNIEnv *env, jobject context) {
jobjectArray ret;

const char *features[] = {
OBFUSCATE("Category_Dead Trigger Mod"),
OBFUSCATE("Toggle_Aimbot"),
OBFUSCATE("Toggle_ESP"),
OBFUSCATE("SeekBar_Zielhoehe_1_2")
};

int Total_Feature = (sizeof features / sizeof features[0]);
ret = (jobjectArray) env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")), env->NewStringUTF(""));

for (int i = 0; i < Total_Feature; i++) {
env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));
}

return (ret);
}

// Reaktionen auf deine Menü-Klicks
void Changes(JNIEnv *env, jclass clazz, jobject obj, jint featNum, jstring featName, jint value, jlong Lvalue, jboolean boolean, jstring text) {
switch (featNum) {
case 0:
enableAimbot = boolean;
break;
case 1:
enableESP = boolean;
break;
case 2:
if (value == 1) aimHeight = 0.8f;
if (value == 2) aimHeight = 1.55f;
break;
}
}

#define targetLibName OBFUSCATE("libil2cpp.so")

// Hook in Agent.Update (Offset: 0x161A10C)
void (*old_Agent_Update)(void *instance);
void Agent_Update(void *instance) {
if (instance != nullptr) {
bool isAlive = Agent_get_IsAlive(instance);
bool isPlayer = Agent_get_IsPlayer(instance);

if (isPlayer) {
localPlayer = instance;
if (enableAimbot && closestEnemy != nullptr) {
if (Agent_get_IsAlive(closestEnemy)) {
void *cam = Camera_get_main();
void *enemyTransform = Component_get_transform(closestEnemy);
if (cam != nullptr && enemyTransform != nullptr) {
void *camTransform = Component_get_transform(cam);
Vector3 targetPos = Transform_get_position(enemyTransform);
targetPos.y += aimHeight;
if (camTransform != nullptr) {
Transform_LookAt(camTransform, targetPos);
}
}
}
closestEnemy = nullptr;
closestDistance = 99999.0f;
}
} else if (isAlive && localPlayer != nullptr) {
void *myTransform = Component_get_transform(localPlayer);
void *enemyTransform = Component_get_transform(instance);
if (myTransform != nullptr && enemyTransform != nullptr) {
Vector3 myPos = Transform_get_position(myTransform);
Vector3 enemyPos = Transform_get_position(enemyTransform);

float dx = enemyPos.x - myPos.x;
float dy = enemyPos.y - myPos.y;
float dz = enemyPos.z - myPos.z;
float dist = sqrtf(dx * dx + dy * dy + dz * dz);

if (dist < closestDistance) {
closestDistance = dist;
closestEnemy = instance;
}

if (enableESP) {
void *mainCam = Camera_get_main();
if (mainCam != nullptr) {
Vector3 screenPos = WorldToScreenPoint(mainCam, enemyPos);
}
}
}
}
}
old_Agent_Update(instance);
}

// Hintergrund-Thread zum Laden deiner Offsets
void *hack_thread(void *) {
while (!isLibraryLoaded(targetLibName)) {
sleep(1);
}

#if defined(__aarch64__)
WorldToScreenPoint = (Vector3 (*)(void *, Vector3))getAbsoluteAddress(targetLibName, OBFUSCATE("0x2A7AE8C"));
Camera_get_main = (void *(*)())getAbsoluteAddress(targetLibName, OBFUSCATE("0x2A7B114"));
Transform_get_position = (Vector3 (*)(void *))getAbsoluteAddress(targetLibName, OBFUSCATE("0x2AB6124"));
Transform_LookAt = (void (*)(void *, Vector3))getAbsoluteAddress(targetLibName, OBFUSCATE("0x2AB74B4"));
Component_get_transform = (void *(*)(void *))getAbsoluteAddress(targetLibName, OBFUSCATE("0x2AFC020"));
Agent_get_IsAlive = (bool (*)(void *))getAbsoluteAddress(targetLibName, OBFUSCATE("0x1616F34"));
Agent_get_IsPlayer = (bool (*)(void *))getAbsoluteAddress(targetLibName, OBFUSCATE("0x1616F10"));

// Hook auf Agent.Update setzen
HOOK(targetLibName, "0x161A10C", Agent_Update, old_Agent_Update);
#endif

LOGI(OBFUSCATE("Dead Trigger Mod geladen!"));
return NULL;
}

__attribute__((constructor))
void lib_main() {
std::thread(hack_thread).detach();
}
